
The tutorial can be found at this URL: http://www.rabbitmq.com/getstarted.html.
The tutorial proposes solutions in Python and Pika, but with Pika version 0.5.
In this project, we use a more recent version.
In addition, we choose the Continuation-Passing Style, instead of instead
of the blocking connections mode. In other words, calling Pika asynchronously
is done by passing in callback methods.

Prerequisites:
- RabbitMQ Server version 2.7.0: http://www.rabbitmq.com/server.html
- Pika (Python implementation of the AMQP 0-9-1) >= 0.9.5: 
  http://pypi.python.org/pypi/pika

To test your whole installation, in a command shell, execute the following 
command:
$ test.bat

Here is the output that you should get

STARTING TEST
Stopping and halting node rabbit@rabbit ...
Error: unable to connect to node rabbit@rabbit: nodedown
diagnostics:
- nodes and their ports on rabbit: [{rabbitmqctl20353,1280}]
- current node: rabbitmqctl20353@rabbit
- current node home dir: C:\Documents and Settings\USER
- current node cookie hash: vzNwDAjGU3kEGjpjdLjEnA==
Activating RabbitMQ plugins ...
0 plugins activated:

Stopping node rabbit@rabbit ...
...done.
Resetting node rabbit@rabbit ...
...done.
Starting node rabbit@rabbit ...
...done.
Listing queues ...
...done.
 [x] Sent 'Hello World!'
END OF TEST
FORCE CLOSE OF CONSUMER
Stopping and halting node rabbit@rabbit ...
...done.
