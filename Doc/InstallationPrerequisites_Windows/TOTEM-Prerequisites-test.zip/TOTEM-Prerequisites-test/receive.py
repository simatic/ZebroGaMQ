import pika
from pika.adapters import SelectConnection

channel = None

def on_connected(connection):
    connection.channel(on_open_callback=on_channel_open)

def on_channel_open(new_channel):
    global channel
    channel = new_channel
    channel.queue_declare(queue="hello",
                          durable=True,
                          exclusive=False,
                          auto_delete=False,
                          callback=on_queue_declared)

def on_queue_declared(frame):
    channel.basic_consume(consumer_callback=handle_delivery,
                          queue='hello')

def handle_delivery(channel, method, header, body):
    print " [x] Received %r" % (body,)
    connection.close()
    connection.ioloop.stop()

def work():
    global parameters
    parameters = pika.ConnectionParameters(host='localhost')
    global connection
    connection = SelectConnection(parameters=parameters,
                                  on_open_callback=on_connected)
    connection.ioloop.start()

if __name__ == '__main__':
    work()
