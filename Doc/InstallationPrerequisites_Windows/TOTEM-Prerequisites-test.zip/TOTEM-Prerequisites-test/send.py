import pika

connection = None
channel = None

def on_closed(frame):
    global connection
    connection.ioloop.stop()

def on_connected(connection):
    global channel
    connection.channel(on_open_callback=on_channel_open)

def on_channel_open(new_channel):
    global channel
    channel = new_channel
    channel.queue_declare(queue="hello",
                          durable=True,
                          exclusive=False,
                          auto_delete=False,
                          callback=on_queue_declared)

def on_queue_declared(frame):
    global channel
    channel.basic_publish(exchange='',
                          routing_key="hello",
                          body="Hello World!",
                          properties=pika.BasicProperties(
                            content_type="text/plain",
                            delivery_mode=1))
    print " [x] Sent 'Hello World!'"
    connection.add_on_close_callback(callback=on_closed)
    connection.close()
    connection.ioloop.stop()

def work():
    global parameters
    parameters = pika.ConnectionParameters(host='localhost')
    global connection
    connection = pika.SelectConnection(parameters=parameters,
                                       on_open_callback=on_connected)
    connection.ioloop.start()

if __name__ == '__main__':
    work()
